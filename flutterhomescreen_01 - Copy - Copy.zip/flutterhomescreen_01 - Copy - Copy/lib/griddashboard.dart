
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class GridDashboard extends StatelessWidget{
  Items item1 = new Items(

  title: "Pressure",
  subtitle: "Atmospheric",
  event: "Current: 1013 hPa",
  img: "assets/map.png",
  icon: Icons.compress, );

  Items item2 = new Items(
    title: "Temperature",
    subtitle: "Outdoor",
    event: "Current: 22°C",
    img: "assets/food.png",
    icon: Icons.thermostat,
  );
  Items item3 = new Items(
    title: "Water Level",
    subtitle: "River",
    event: "Current: 3.5m",
    img: "assets/calendar.png",
    icon: Icons.water,
  );
  Items item4 = new Items(
    title: "Humidity",
    subtitle: "Relative",
    event: "Current: 65%",
    img: "assets/festival.png",
    icon: Icons.water_drop,
  );

  @override
  Widget build(BuildContext context) {
    List<Items> myList = [item1, item2, item3, item4,];
    var color = 0xff453658;
    return Flexible(
      child: GridView.count(
          childAspectRatio: 0.6,
          padding: EdgeInsets.only(left: 16, right: 16, ),
          crossAxisCount: 2,
          crossAxisSpacing: 18,
          mainAxisSpacing: 3,
          children: myList.map((data) {
            return Container(
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Image.asset(
                    data.img,
                    width: 42,
                  ),
                  SizedBox(
                    height: 14,
                  ),
                  Text(
                    data.title,
                    style: GoogleFonts.openSans(
                        textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w600)),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Text(
                    data.subtitle,
                    style: GoogleFonts.openSans(
                        textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontWeight: FontWeight.w600)),
                  ),
                  SizedBox(
                    height: 14,
                  ),
                  Text(
                    data.event,
                    style: GoogleFonts.openSans(
                        textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 11,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            );
          }).toList()),
    );
  }
}

class Items {
  String title;
  String subtitle;
  String event;
  String img;
  Items({required this.title, required this.subtitle, required this.event, required this.img, required IconData icon});
}
